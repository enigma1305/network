#include<iostrem>
#include<time.h>
#include<stdlib.h>
#include<math.h>
using namespace std;
int TOT_FRAME=500;
int FRAME_SEND=16;
class gobkn
{
    private:
    int fr_send;
    int arr[TOT_FRAMES];
    int arr1[FRAMES_SEND];
    int rw;
    int sw;
    public:
    gobbkn();
    void input();
    void sender(int m);
    void reciever(int m);
};
gobkn::gobkn()
{
    rw=0;
    sw=0
}
gobkn::input()
{
    int n,m;
    do
    {
        cout<<"Enter the no of bits for sequence number :";
        cin>>n;
        if(n>5)
        {
            cout<<"ERROR:Please enter a number b/w 0 and 4.";
        }
    }while(n>5);
    m=pow(2,n);
    fr_send=m-1;
    int t=0;
    cout<<"No of frames sent at an instance :"<<fr_send;
    for(int i=0;i<fr_send;i++)
    {
        arr[i]=t;
        t=(t+1)%m;
    }
    sender(m);
}
gobkn::sender(int m)
{
        cout<<"<SENDER>";
        int j=0;
        for(int i=sw;i<sw+fr_send;i++)
        {
        arr1[j++]=arr[i];
        }
        for(int =0;i<j;i++)
        {
        cout<<"SENDER:FRAME "<<arr1[i]<<" SENT!\n";
        }
        reciever(m);
}
gobkn::reciever(int m)
{
        cout<<"<RECIEVER>";
        time_t t;
        srand(unsigned) time(&t));
        int f=rand()%fr_send;

        if(f!=4)
        {
            int i=0;
            for(int i=0;i<fr_send;i++)
            {
                if(rw==arr1[i])
                {
                    cout<<"RECIEVER:FRAME "<<arr1[i]<<" recieved correctly.";
                    rw=(rw+1)%m;
                }
                else
                {
                    cout<<"DUPLICATE:FRAME "<<arr1[i]<<" discarded.";
                }

            }
            f=rand()%fr_send;

            if(f>fr_send/2)
            {


        }
}
